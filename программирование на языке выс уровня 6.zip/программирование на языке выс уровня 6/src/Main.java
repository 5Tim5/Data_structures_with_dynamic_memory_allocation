public class Main {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        list.addToEnd(1);
        list.addToEnd(2);
        list.addToEnd(3);
        list.addToEnd(4);
        list.addToEnd(5);

        System.out.println("Исходный список:");
        list.print();

        // Выполняем циклический сдвиг вправо на 2 позиции
        // Ожидаемый результат: 4 → 5 → 1 → 2 → 3
        list.rotateRight(2);

        // Выводим результат после сдвига
        System.out.println("\nПосле сдвига вправо на 2:");
        list.print();
    }
}


class Node {
    int data;      // данные, которые хранит узел (в нашем случае целое число)
    Node next;     // ссылка на следующий узел в списке


    Node(int data) {
        this.data = data;   // сохраняем переданное число
        this.next = null;   // следующий узел пока неизвестен
    }
}


class LinkedList {
    Node head;     // ссылка на ПЕРВЫЙ узел списка (голова)
    // если head == null, значит список пуст
    void addToEnd(int value) {
        // ШАГ 1: создаём новый узел с переданным значением
        Node newNode = new Node(value);

        // ШАГ 2: проверяем, пуст ли список
        if (head == null) {
            // Если список пуст, новый узел становится головой
            head = newNode;
        } else {
            // ШАГ 3: список не пуст, нужно найти последний узел
            Node current = head;   // начинаем поиск с головы

            // Идём по цепочке, пока не найдём узел, у которого next == null
            while (current.next != null) {
                current = current.next;   // переходим к следующему узлу
            }
            // Теперь current указывает на последний узел списка
            // Привязываем новый узел как следующий за последним
            current.next = newNode;
        }
    }
    void rotateRight(int k) {
        // Если список пуст (нет элементов) или содержит один элемент,
        // или сдвиг на 0 - ничего не делаем
        if (head == null || head.next == null || k == 0) {
            return;
        }

        // ========== ШАГ 1: Находим длину списка и последний узел ==========
        int length = 1;          // начинаем с 1, так как голова - это уже один элемент
        Node last = head;        // начинаем с головы

        // Проходим по всем узлам, пока не дойдём до конца
        while (last.next != null) {
            last = last.next;    // переходим к следующему узлу
            length++;            // увеличиваем счётчик длины
        }

        // ========== ШАГ 2: Оптимизируем k ==========
        k = k % length;

        // Если после оптимизации k = 0, сдвиг не нужен
        if (k == 0) {
            return;
        }

        // ========== ШАГ 3: Замыкаем список в кольцо ==========
        last.next = head;

        // ========== ШАГ 4: Находим новый хвост ==========
        Node newTail = head;     // начинаем с головы

        for (int i = 1; i < length - k; i++) {
            newTail = newTail.next;
        }

        // ========== ШАГ 5: Новая голова ==========
        // Новая голова - это узел, следующий за новым хвостом
        Node newHead = newTail.next;   // newTail.next = узел, который становится первым

        // ========== ШАГ 6: Разрываем кольцо ==========
        // Новый хвост теперь указывает на null (становится последним)
        newTail.next = null;

        // ========== ШАГ 7: Обновляем голову списка ==========
        head = newHead;
    }
    void print() {
        // Если голова указывает на null, список пуст
        if (head == null) {
            System.out.println("Список пуст");
            return;
        }

        // Начинаем с головы
        Node current = head;

        // Пока не дошли до конца (current != null)
        while (current != null) {
            // Печатаем данные текущего узла
            System.out.print(current.data);

            // Если есть следующий узел, печатаем стрелку
            if (current.next != null) {
                System.out.print(" → ");
            }
            // Переходим к следующему узлу
            current = current.next;
        }

        // В конце печатаем NULL, обозначая конец списка
        System.out.println(" → NULL");
    }
}